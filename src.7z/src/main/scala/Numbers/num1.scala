package Numbers

object num1 {
  def main(args: Array[String]): Unit = {
    val a="100".toInt
    println(a)
    val b="1".toLong
    println(b)
    val c = BigInt("1")
    println(c)

  }

}
