package Numbers

object num2 {
  def main(args: Array[String]): Unit = {
    var a = 1
    a += 2
    println(a)
    var i = 2
    i *= 2
    println(i)
//    val x=1
//     x+=1
//    println(x)
  }
}
