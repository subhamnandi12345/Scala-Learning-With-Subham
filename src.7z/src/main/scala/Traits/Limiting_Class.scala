package Traits
trait  A {

}
trait B {

}
abstract class C{


}
//class Exam extends A with B with C
//object ObjectName extends Class with Trait
class Ran extends C with B


class Limiting_Class {

}
