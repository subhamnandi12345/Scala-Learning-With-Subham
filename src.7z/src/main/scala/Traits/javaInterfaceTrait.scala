package Traits
//
//class Dog11 extends Animal with Wagging with Running {
//  def speak111 { println("Woof") }
//  def wag { println("Tail is wagging!") }
//  def run { println("I'm running!") }
//}
//object scala11 extends App{
//
//}