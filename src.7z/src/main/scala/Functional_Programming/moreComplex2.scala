package Functional_Programming

//object func3 extends App{
//  def executeXTimes(callback: (Int,Int) => Int, numTimes: Int) {
//    for (i <- 1 to numTimes)
//  }
//  val sayHello = () => println("Hello")
//  val sum=(i:Int,j:Int)=>{i+j}
// // executeXTimes(sum(4,5), 3)
//
//  //val sum = (x: Int, y: Int) => x + y
//}
