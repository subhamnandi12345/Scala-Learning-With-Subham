package packA

class Animal {
  protected def breathe {}
}

