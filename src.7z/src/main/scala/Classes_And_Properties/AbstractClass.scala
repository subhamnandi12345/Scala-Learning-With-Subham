package Classes_And_Properties

 abstract class AbstructClass {
 def save()
  def call(): Unit = {
    println("hello")
  }
}
class abc extends AbstructClass{
   def save{

  }
}