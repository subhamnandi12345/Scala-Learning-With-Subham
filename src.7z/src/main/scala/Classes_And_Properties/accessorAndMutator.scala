package Classes_And_Properties

import scala.beans.BeanProperty

//class Person(private var _name: String) {
//  def name = _name       //accessor
//  def name_=(aName: String) { _name = aName }   //mutator
//}
//object example{
//  def main(args: Array[String]): Unit = {
//    val p = new Person("Jonathan")
//    p.name = "John" // setter , behind the scens  p.name_$eq="John"
//    println(p.name) // getter
//  }
//}
