package Objects_Chapter
object ob1{
  def main(args: Array[String]): Unit = {
//    val a = 10
//    val b = a.asInstanceOf[Long]
//    println(b);
//    println(b.getClass)  // to check the datatype
     //var a=1
     val a=classOf[String]
    //a.charAt()
    val b: String = "scala"

  }}

