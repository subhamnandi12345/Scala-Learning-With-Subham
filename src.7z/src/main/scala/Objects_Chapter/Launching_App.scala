package Objects_Chapter

object Hello2 extends  App{
   println("hello scala")
}
