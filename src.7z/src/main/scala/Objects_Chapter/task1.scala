package Objects_Chapter

class task1 extends App{
  def display= println("Hello World")
}
object sub {
  val a=new task1
  a.display
}

