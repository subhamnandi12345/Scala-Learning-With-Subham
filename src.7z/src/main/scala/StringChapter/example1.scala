package StringChapter

object example1 {
  def main(args: Array[String]): Unit = {


    val s="subham"
   val l="subham"
    val a=s
    println(l==a)
    println(l.equals(a))
//   "Hello ,World ".foreach(println)
//    s.foreach(println)
//    //accessing a character in a string
   println("hello"(0))
   //or
//    val a="Software"
//    //println(a(1))
//    var index= scala.io.StdIn.readInt()
//    println(a(index))

  }
}
