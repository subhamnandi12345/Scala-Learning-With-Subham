package packB
import packA.Animal
class Dog extends Animal {
  breathe
}

